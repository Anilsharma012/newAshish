// server/services/phonepe.ts
import axios from "axios";
import crypto from "crypto";

const BASE_URL = process.env.PHONEPE_BASE_URL as string;      // e.g. https://api-preprod.phonepe.com/apis/pg-sandbox
const MERCHANT_ID = process.env.PHONEPE_MERCHANT_ID as string; // e.g. SU2507...
const SALT_KEY = process.env.PHONEPE_SALT_KEY as string;       // e.g. ac27ec7e-...
const SALT_INDEX = (process.env.PHONEPE_SALT_INDEX as string) || "1";

function sha256Hex(input: string) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

/**
 * Create a PhonePe Pay Page order
 * Returns the raw response (redirect URL is usually at data.instrumentResponse.redirectInfo.url)
 */
export async function createPayPageOrder(args: {
  merchantTransactionId: string;
  amountPaise: number;         // ₹100.00 => 10000
  merchantUserId: string;      // your internal user id
  mobileNumber?: string;       // optional
  redirectUrl: string;         // where PhonePe should redirect after payment
  callbackUrl?: string;        // optional webhook URL
}) {
  const payload = {
    merchantId: MERCHANT_ID,
    merchantTransactionId: args.merchantTransactionId,
    merchantUserId: String(args.merchantUserId),
    amount: args.amountPaise,
    redirectUrl: args.redirectUrl,
    redirectMode: "REDIRECT",
    callbackUrl: args.callbackUrl, // optional; we will also poll status from client
    mobileNumber: args.mobileNumber,
    paymentInstrument: { type: "PAY_PAGE" },
  };

  const payloadB64 = Buffer.from(JSON.stringify(payload)).toString("base64");

  const endpointPath = "/pg/v1/pay";
  const xVerify = sha256Hex(payloadB64 + endpointPath + SALT_KEY) + "###" + SALT_INDEX;

  const headers = {
    "Content-Type": "application/json",
    "X-VERIFY": xVerify,
    "X-MERCHANT-ID": MERCHANT_ID,
  };

  const url = `${BASE_URL}${endpointPath}`;
  const resp = await axios.post(url, { request: payloadB64 }, { headers });

  return resp.data;
}

/**
 * Check the payment status for a merchantTransactionId
 */
export async function checkStatus(merchantTransactionId: string) {
  const endpointPath = `/pg/v1/status/${MERCHANT_ID}/${merchantTransactionId}`;
  const xVerify = sha256Hex(endpointPath + SALT_KEY) + "###" + SALT_INDEX;

  const headers = {
    "Content-Type": "application/json",
    "X-VERIFY": xVerify,
    "X-MERCHANT-ID": MERCHANT_ID,
  };

  const url = `${BASE_URL}${endpointPath}`;
  const resp = await axios.get(url, { headers });

  return resp.data;
}
