// server/routes/phonepe.ts
import express from "express";
import {
  createPhonePeTransaction,
  phonePeCallback,
  getPhonePePaymentStatus,
  getPaymentMethodsWithPhonePe,
} from "../controllers/phonepe-payments";

const router = express.Router();

// Create PhonePe order (returns redirect URL)
router.post("/payments/phonepe/create", createPhonePeTransaction);

// PhonePe server callback/webhook (kept JSON)
router.post(
  "/payments/phonepe/callback",
  express.json({ type: "*/*" }),
  phonePeCallback
);

// Poll status by merchantTransactionId
router.get(
  "/payments/phonepe/status/:merchantTransactionId",
  getPhonePePaymentStatus
);

// (Optional) expose methods list incl. phonepe toggle from admin_settings
router.get("/payments/methods", getPaymentMethodsWithPhonePe);

export default router;
