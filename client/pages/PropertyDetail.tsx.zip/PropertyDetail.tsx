import { useState, useEffect } from "react";
import { useParams, useNavigate, Link, useLocation } from "react-router-dom";
import {
  MessageCircle,
  Phone,
  Share2,
  Heart,
  MapPin,
  Bed,
  Bath,
  Send,
  Square,
  Car,
  Calendar,
  Eye,
  ChevronLeft,
  ChevronRight,
  ArrowLeft,
} from "lucide-react";
import { useWatermark } from "../hooks/useWatermark";
import Watermark from "../components/Watermark";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { toast } from "../components/ui/use-toast";
import ApiDiagnostic from "../components/ApiDiagnostic";
import EnquiryModal from "../components/EnquiryModal";
import PropertyReviews from "../components/PropertyReviews";
import ReviewsList from "../components/ReviewsList";
import ReviewForm from "../components/ReviewForm";
import { useAuth } from "../hooks/useAuth";

interface Property {
  _id: string;
  title: string;
  description: string;
  propertyType: string;
  subCategory: string;
  price: number;
  priceType: "sale" | "rent";
  location: {
    city: string;
    state: string;
    address: string;
    area?: string;
  };
  contactInfo: {
    name: string;
    phone: string;
    whatsappNumber?: string;
    email: string;
  };
  images: any[];
  status: "active" | "inactive" | "sold" | "rented";
  featured: boolean;
  premium: boolean;
  specifications?: {
    bedrooms?: number;
    bathrooms?: number;
    area?: string;
    facing?: string;
    floor?: string;
    totalFloors?: string;
    parking?: boolean;
    furnished?: string;
  };
  amenities?: string[];
  views: number;
  inquiries: number;
  createdAt: string;
}

export default function PropertyDetail() {
  useWatermark();
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  // ✅ Central auth
  const { user, token, isAuthenticated, loading: authLoading } = useAuth();

  // ✅ Bridge: if other components read different token keys, mirror once
  useEffect(() => {
    const t = token || localStorage.getItem("token");
    if (t) {
      if (!localStorage.getItem("accessToken")) localStorage.setItem("accessToken", t);
      if (!localStorage.getItem("authToken")) localStorage.setItem("authToken", t);
    }
  }, [token]);

  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>("");
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [enquiryModalOpen, setEnquiryModalOpen] = useState(false);
  const [startingChat, setStartingChat] = useState(false);

  useEffect(() => {
    if (id) {
      fetchProperty();
      trackView();
    }
  }, [id]);

  const fetchProperty = async (retryCount = 0) => {
    try {
      setLoading(true);
      setError("");

      if (!id) {
        setError("Property ID is required");
        setLoading(false);
        return;
      }
      if (id.length !== 24) {
        setError("Invalid property ID format");
        setLoading(false);
        return;
      }

      const apiResponse = await (window as any).api(`properties/${id}`);

      if (apiResponse.ok) {
        const data = apiResponse.json;
        if (data.success) {
          setProperty(data.data);
        } else {
          setError(data.error || "Property not found");
        }
      } else if (apiResponse.status === 404) {
        setError("Property not found");
      } else if (apiResponse.status === 400) {
        setError("Invalid property ID");
      } else {
        const errorData = apiResponse.json;
        setError(errorData.error || "Failed to load property");
      }
    } catch (error: any) {
      let errorMessage = "Failed to load property";
      if (
        error.name === "TypeError" &&
        String(error.message).includes("Failed to fetch")
      ) {
        if (retryCount < 2) {
          setTimeout(() => fetchProperty(retryCount + 1), 1000 * (retryCount + 1));
          return;
        } else {
          errorMessage =
            "Network error. Please check your internet connection and try again.";
        }
      } else if (String(error.message).includes("Invalid JSON")) {
        errorMessage = "Server error. Please try again later.";
      } else if (error.message) {
        errorMessage = error.message;
      }
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const trackView = async () => {
    try {
      const url = `/api/analytics/view/${id}`;
      if (navigator.sendBeacon) {
        const blob = new Blob([JSON.stringify({ ts: Date.now() })], {
          type: "application/json",
        });
        navigator.sendBeacon(url, blob);
        return;
      }
      await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ts: Date.now() }),
      });
    } catch {}
  };

  const handleCall = (phoneNumber: string) => {
    const url = `/api/analytics/phone/${id}`;
    try {
      if (navigator.sendBeacon) {
        const blob = new Blob([JSON.stringify({ ts: Date.now() })], {
          type: "application/json",
        });
        navigator.sendBeacon(url, blob);
      } else {
        fetch(url, {
          method: "POST",
          keepalive: true,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ts: Date.now() }),
        }).catch(() => {});
      }
    } catch {}
    window.open(`tel:${phoneNumber}`, "_self");
  };

  const handleWhatsApp = (phoneNumber: string) => {
    const message = `Hi, I'm interested in your property: ${property?.title}`;
    const url = `https://wa.me/${phoneNumber.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(
      message
    )}`;
    window.open(url, "_blank");
  };

  const handleStartChat = async () => {
    try {
      const t = token || localStorage.getItem("token");
      if (!t) {
        navigate("/login", {
          state: {
            redirectTo: `/property/${id}`,
            message: "Please login to start chat",
          },
        });
        return;
      }
      if (!property?._id) {
        toast({
          title: "Error",
          description: "Property information not available",
          variant: "destructive",
        });
        return;
      }
      setStartingChat(true);
      let response = await (window as any).api(`conversations`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${t}`,
        },
        body: { propertyId: property._id },
      });
      if (!response.success) {
        response = await (window as any).api(`conversations/find-or-create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${t}`,
          },
          body: { propertyId: property._id },
        });
      }
      if (response.success) {
        const convId = response.data?._id || response.data?.conversationId;
        if (!convId) {
          toast({
            title: "Error",
            description: "Invalid conversation id",
            variant: "destructive",
          });
          return;
        }
        navigate(`/conversation/${convId}`);
      } else {
        toast({
          title: "Error",
          description: response.error || "Failed to start chat",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error starting chat:", error);
      toast({
        title: "Error",
        description: "Failed to start chat. Please try again.",
        variant: "destructive",
      });
    } finally {
      setStartingChat(false);
    }
  };

  const nextImage = () => {
    if (property?.images)
      setCurrentImageIndex((p) =>
        p === property.images.length - 1 ? 0 : p + 1
      );
  };
  const prevImage = () => {
    if (property?.images)
      setCurrentImageIndex((p) =>
        p === 0 ? property.images.length - 1 : p - 1
      );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-[#C70000] border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading property details...</p>
        </div>
      </div>
    );
  }

  if (error || !property) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-4xl w-full space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Property Not Found
            </h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <Button onClick={() => navigate(-1)} variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Go Back
            </Button>
          </div>
          <ApiDiagnostic propertyId={id} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="flex items-center"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsLiked(!isLiked)}
                className={isLiked ? "text-red-500" : ""}
              >
                <Heart className={`h-4 w-4 ${isLiked ? "fill-current" : ""}`} />
              </Button>
              <Button variant="ghost" size="sm">
                <Share2 className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                disabled={startingChat}
                className="bg-[#C70000] hover:bg-[#A60000] text-white"
                onClick={handleStartChat}
              >
                {startingChat ? (
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-1" />
                ) : (
                  <MessageCircle className="h-4 w-4 mr-1" />
                )}
                {startingChat ? "Starting..." : "Message Owner"}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Images + Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            {property.images.length > 0 && (
              <Card>
                <CardContent className="p-0">
                  <div className="relative aspect-video">
                    <img
                      src={
                        property.images[currentImageIndex]?.url ||
                        property.images[currentImageIndex] ||
                        "/placeholder.png"
                      }
                      alt={property.title}
                      className="w-full h-full object-cover rounded-t-lg"
                    />
                    <Watermark small />
                    {property.images.length > 1 && (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/40 text-white"
                          onClick={prevImage}
                        >
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/40 text-white"
                          onClick={nextImage}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Property Details */}
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-gray-900">
                  {property.title}
                </CardTitle>
                <div className="flex items-center text-gray-600 mt-1">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>
                    {property.location.area}, {property.location.city}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-[#C70000] mb-3">
                  ₹{property.price.toLocaleString()}{" "}
                  {property.priceType === "rent" && (
                    <span className="text-lg">/month</span>
                  )}
                </div>
                <p className="text-gray-700 whitespace-pre-line">
                  {property.description}
                </p>

                {/* Ratings / summary */}
                <PropertyReviews propertyId={property._id} />

                {/* Public list */}
                <ReviewsList targetId={property._id} targetType="property" />

                {/* ✅ Review form only when logged-in; force remount on auth change */}
                {authLoading ? (
                  <div className="text-sm text-gray-500 mt-2">Checking login…</div>
                ) : isAuthenticated ? (
                  <ReviewForm
                    key={user?._id || "authed"}
                    targetId={property._id}
                    targetType="property"
                  />
                ) : (
                  <div className="mt-2 text-sm">
                    Login to write a review.{" "}
                    <Link
                      to="/login"
                      state={{ redirectTo: location.pathname }}
                      className="text-[#C70000] underline"
                    >
                      Login
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Contact Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="font-medium">{property.contactInfo.name}</p>
                  <p className="text-sm text-gray-600">
                    {property.contactInfo.email}
                  </p>
                </div>

                {/* Desktop */}
                <div className="hidden md:flex flex-col space-y-3">
                  <Button
                    className="w-full bg-[#C70000] hover:bg-[#A60000] text-white flex justify-center items-center py-3"
                    onClick={handleStartChat}
                  >
                    <MessageCircle className="h-4 w-4 mr-2" /> Message
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-[#C70000] text-[#C70000] hover:bg-[#C70000] hover:text-white flex justify-center items-center py-3"
                    onClick={() => handleCall(property.contactInfo.phone)}
                  >
                    <Phone className="h-4 w-4 mr-2" /> Call
                  </Button>
                  <Button
                    className="w-full bg-green-500 hover:bg-green-600 text-white flex justify-center items-center py-3"
                    onClick={() =>
                      handleWhatsApp(
                        property.contactInfo.whatsappNumber ||
                          property.contactInfo.phone
                      )
                    }
                  >
                    WhatsApp
                  </Button>
                </div>

                {/* ✅ Mobile – Fixed Vertical Layout */}
                <div className="space-y-3 md:hidden">
                  <Button
                    className="w-full bg-[#C70000] hover:bg-[#A60000] text-white flex justify-center items-center py-3 rounded-md"
                    onClick={handleStartChat}
                    disabled={startingChat}
                  >
                    {startingChat ? (
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                    ) : (
                      <MessageCircle className="h-4 w-4 mr-2" />
                    )}
                    <span>{startingChat ? "Starting..." : "Message"}</span>
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full border-[#C70000] text-[#C70000] hover:bg-[#C70000] hover:text-white flex justify-center items-center py-3 rounded-md"
                    onClick={() => handleCall(property.contactInfo.phone)}
                  >
                    <Phone className="h-4 w-4 mr-2" /> Call
                  </Button>

                  <Button
                    className="w-full bg-green-500 hover:bg-green-600 text-white flex justify-center items-center py-3 rounded-md"
                    onClick={() =>
                      handleWhatsApp(
                        property.contactInfo.whatsappNumber ||
                          property.contactInfo.phone
                      )
                    }
                  >
                    WhatsApp
                  </Button>
                </div>

                <div className="pt-4 border-t">
                  <p className="text-xs text-gray-500 text-center">
                    Contact details are verified by our team
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {property && (
        <EnquiryModal
          isOpen={enquiryModalOpen}
          onClose={() => setEnquiryModalOpen(false)}
          propertyId={property._id}
          propertyTitle={property.title}
          ownerName={property.contactInfo.name}
        />
      )}
    </div>
  );
}
