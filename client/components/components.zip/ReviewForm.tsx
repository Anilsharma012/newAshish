import React, { useEffect, useState } from "react";
import { submitReview, getToken } from "../lib/reviewsApi";
import { Link, useLocation } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "../hooks/useAuth";

export default function ReviewForm({
  targetId,
  targetType = "property",
}: {
  targetId: string;
  targetType?: string;
}) {
  const { toast } = useToast();
  const location = useLocation();

  // ✅ central auth (live)
  const { token: ctxToken, isAuthenticated, loading: authLoading, user } = useAuth();

  // ✅ keep a reactive token with fallback to any localStorage token
  const [token, setToken] = useState<string | null>(ctxToken || getToken() || null);

  useEffect(() => {
    setToken(ctxToken || getToken() || null);
  }, [ctxToken]);

  // ✅ also react if some other tab/login writes token into storage
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (!e.key) return;
      if (["token", "accessToken", "authToken"].includes(e.key)) {
        setToken(ctxToken || getToken() || null);
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [ctxToken]);

  const [rating, setRating] = useState<number>(0);
  const [title, setTitle] = useState("");
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [pendingNote, setPendingNote] = useState<string>("");

  // Small UX helper: after submit we can tell user that review may be pending moderation
  useEffect(() => {
    setPendingNote("Your review may appear after approval.");
  }, []);

  if (authLoading) {
    return <div className="mt-4 text-sm text-gray-500">Checking login…</div>;
  }

  if (!token) {
    return (
      <div className="mt-4 text-sm">
        <span className="text-gray-600">Login to write a review. </span>
        <Link
          to="/login"
          state={{ redirectTo: location.pathname }}
          className="text-[#C70000] hover:underline"
        >
          Login
        </Link>
      </div>
    );
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rating || rating < 1 || rating > 5) {
      toast({ title: "Rating required", description: "Please select 1–5 stars" });
      return;
    }
    if (comment.trim().length < 10 || comment.trim().length > 600) {
      toast({ title: "Comment length", description: "Please write 10–600 characters" });
      return;
    }

    setSubmitting(true);
    try {
      // 🔐 ensure token present (double-check)
      const activeToken = token || ctxToken || getToken();
      if (!activeToken) throw new Error("Not authenticated");

      const res = await submitReview({
        targetId,
        targetType,
        rating,
        title: title.trim() || undefined,
        comment: comment.trim(),
        token: activeToken, // pass explicitly if your helper supports it
        userId: user?._id,  // optional, harmless if API ignores
      });

      if (res?.success) {
        toast({ title: "Thanks!", description: "Your review was submitted." });
        setRating(0);
        setTitle("");
        setComment("");
        // let lists listening refresh
        window.dispatchEvent(new CustomEvent("reviews:submitted", { detail: { targetId, targetType } }));
      } else {
        throw new Error(res?.error || "Failed to submit review");
      }
    } catch (err: any) {
      toast({
        title: "Submit failed",
        description: err?.message || "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mt-4">
      {pendingNote && (
        <div className="text-xs text-gray-500 mb-2" aria-live="polite">
          {pendingNote}
        </div>
      )}
      <form onSubmit={onSubmit} className="rounded-xl shadow-sm border p-4 bg-white">
        <label className="block text-sm font-medium mb-1">Rating</label>
        <div className="flex items-center space-x-2 mb-3">
          {[1, 2, 3, 4, 5].map((s) => (
            <button
              key={s}
              type="button"
              aria-label={`Rate ${s}`}
              onClick={() => setRating(s)}
              className={`text-2xl ${s <= rating ? "text-amber-400" : "text-gray-300"}`}
            >
              ★
            </button>
          ))}
        </div>

        <label className="block text-sm font-medium mb-1" htmlFor="title">
          Title (optional)
        </label>
        <input
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Short headline"
          className="w-full border rounded-md px-3 py-2 mb-3 outline-none focus:ring-2 focus:ring-red-200"
        />

        <label className="block text-sm font-medium mb-1" htmlFor="comment">
          Your review
        </label>
        <textarea
          id="comment"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Share details about your experience"
          rows={4}
          className="w-full border rounded-md px-3 py-2 mb-4 outline-none focus:ring-2 focus:ring-red-200"
        />

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={submitting}
            className="bg-[#C70000] hover:bg-red-700 disabled:opacity-50 text-white px-4 py-2 rounded-md"
          >
            {submitting ? "Submitting..." : "Submit Review"}
          </button>
        </div>
      </form>
    </div>
  );
}
