// server/firebaseAdmin.ts
import admin from "firebase-admin";
import fs from "fs";
import path from "path";

function readJsonFileSafe(p: string): any | null {
  try {
    if (!fs.existsSync(p)) return null;
    return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch {
    return null;
  }
}

function normalizeSvc(svc: any | null): any | null {
  if (!svc) return null;
  if (svc.private_key) {
    const k = String(svc.private_key);
    svc.private_key = k.includes("\\n") ? k.replace(/\\n/g, "\n") : k;
  }
  return svc;
}

function looksLikePem(key?: string) {
  return !!key && key.includes("BEGIN PRIVATE KEY") && key.includes("END PRIVATE KEY");
}

function resolveServiceAccount(): any {
  // 1) Explicit file path (best)
  const envPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH;
  if (envPath) {
    const parsed = normalizeSvc(readJsonFileSafe(envPath));
    if (!parsed) throw new Error(`FIREBASE_SERVICE_ACCOUNT_PATH not readable: ${envPath}`);
    if (!looksLikePem(parsed.private_key)) throw new Error(`Service account at ${envPath} has invalid private_key`);
    console.log("[FB-ADMIN] Using credentials from PATH:", envPath);
    return parsed;
  }

  // 2) GOOGLE_APPLICATION_CREDENTIALS
  const gac = process.env.GOOGLE_APPLICATION_CREDENTIALS;
  if (gac) {
    const parsed = normalizeSvc(readJsonFileSafe(gac));
    if (parsed && looksLikePem(parsed.private_key)) {
      console.log("[FB-ADMIN] Using credentials from GAC:", gac);
      return parsed;
    }
  }

  // 3) Inline JSON
  const envJson = process.env.FIREBASE_SERVICE_ACCOUNT;
  if (envJson) {
    try {
      const parsed = normalizeSvc(JSON.parse(envJson));
      if (!looksLikePem(parsed.private_key)) throw new Error("private_key bad format");
      console.warn("[FB-ADMIN] Using INLINE service account (ensure \\n are escaped)");
      return parsed;
    } catch {
      throw new Error("FIREBASE_SERVICE_ACCOUNT invalid JSON");
    }
  }

  // 4) Default repo path
  const defaultPath = path.resolve(process.cwd(), "server/credentials/firebase-service-account.json");
  const parsed = normalizeSvc(readJsonFileSafe(defaultPath));
  if (parsed && looksLikePem(parsed.private_key)) {
    console.log("[FB-ADMIN] Using credentials from default path:", defaultPath);
    return parsed;
  }

  throw new Error("Missing Firebase service account (set FIREBASE_SERVICE_ACCOUNT_PATH / GAC / FIREBASE_SERVICE_ACCOUNT or place server/credentials/firebase-service-account.json)");
}

let _ready = false;

export function getAdmin(): typeof admin {
  if (_ready && admin.apps.length > 0) return admin;

  const svc = resolveServiceAccount();
  if (!svc.client_email || !svc.private_key || !svc.project_id) {
    throw new Error("Service account missing client_email/private_key/project_id");
  }

  if (admin.apps.length === 0) {
    // ✅ IMPORTANT: use the service account object directly to avoid project mismatch
    admin.initializeApp({
      credential: admin.credential.cert({
        clientEmail: svc.client_email,
        privateKey: svc.private_key,
        projectId: svc.project_id,
      }),
      projectId: svc.project_id,
    });
    console.log("[FB-ADMIN] Initialized for project:", svc.project_id);
  }

  _ready = true;
  return admin;
}

export const adminAuth = () => getAdmin().auth();
