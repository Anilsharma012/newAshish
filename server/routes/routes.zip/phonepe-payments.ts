// server/controllers/phonepe-payments.ts

import { RequestHandler } from "express";
import { getDatabase } from "../db/mongodb";
import { ApiResponse } from "@shared/types";
import crypto from "crypto";
import { ObjectId } from "mongodb";

// NOTE: Node 18+ me global fetch hota hai. Agar tum Node 16 use kar rahe ho,
// to top pe uncomment kardo:
// // @ts-ignore
// import fetch from "node-fetch";

interface PhonePeConfig {
  enabled: boolean;
  merchantId: string;
  saltKey: string;
  saltIndex: string; // string per PhonePe docs
  testMode: boolean;
}

/* ------------------------------ Utils ------------------------------ */

const getBaseUrl = (req: any) => {
  // behind proxy? set trust proxy in app and use req.get('host')
  const proto = (req.headers["x-forwarded-proto"] as string) || req.protocol || "http";
  const host = req.get("host");
  return `${proto}://${host}`;
};

// Get PhonePe configuration from admin_settings
const getPhonePeConfig = async (): Promise<PhonePeConfig | null> => {
  try {
    const db = getDatabase();
    const settings = await db.collection("admin_settings").findOne({});

    const cfg = settings?.payment?.phonePe as PhonePeConfig | undefined;
    if (!cfg?.enabled) return null;

    if (!cfg.merchantId || !cfg.saltKey || !cfg.saltIndex) {
      console.error("❌ PhonePe config incomplete", {
        hasMerchantId: !!cfg?.merchantId,
        hasSaltKey: !!cfg?.saltKey,
        hasSaltIndex: !!cfg?.saltIndex,
      });
      return null;
    }

    return {
      enabled: true,
      merchantId: cfg.merchantId,
      saltKey: cfg.saltKey,
      saltIndex: String(cfg.saltIndex),
      testMode: !!cfg.testMode,
    };
  } catch (e) {
    console.error("Error reading PhonePe config:", e);
    return null;
  }
};

// Per PhonePe spec: sha256(base64Payload + APIPath + saltKey) + "###" + saltIndex
const generateChecksum = (base64Payload: string, endpoint: string, saltKey: string, saltIndex: string) => {
  const data = base64Payload + endpoint + saltKey;
  const hash = crypto.createHash("sha256").update(data).digest("hex");
  return `${hash}###${saltIndex}`;
};

// For callback/status verify: sha256(response + saltKey) === x-verify hash
const verifyChecksum = (responseBase64: string, xVerify: string, saltKey: string) => {
  try {
    const [hash] = (xVerify || "").split("###");
    const calc = crypto.createHash("sha256").update(responseBase64 + saltKey).digest("hex");
    return calc === hash;
  } catch {
    return false;
  }
};

/* ------------------------------ Handlers ------------------------------ */

/**
 * POST /api/payments/phonepe/create
 * Creates a transaction in our DB + initiates PhonePe Pay Page.
 * Frontend expects data.instrumentResponse.redirectInfo.url to redirect.
 */
export const createPhonePeTransaction: RequestHandler = async (req, res) => {
  try {
    const db = getDatabase();

    const userIdRaw = (req as any).userId as string | undefined;
    if (!userIdRaw) {
      return res.status(401).json({ success: false, error: "Please login to continue" });
    }
    const userId = new ObjectId(userIdRaw);

    const { packageId, propertyId, paymentMethod, paymentDetails } = req.body as {
      packageId: string;
      propertyId?: string;
      paymentMethod: string; // should be 'phonepe'
      paymentDetails: { merchantTransactionId: string; [k: string]: any };
    };

    if (!packageId || !paymentMethod || !paymentDetails?.merchantTransactionId) {
      return res.status(400).json({
        success: false,
        error: "Missing required fields: packageId, paymentMethod, paymentDetails.merchantTransactionId",
      });
    }

    const config = await getPhonePeConfig();
    if (!config) {
      return res.status(400).json({
        success: false,
        error: "PhonePe is not configured/enabled. Please contact support.",
      });
    }

    let pkgId: ObjectId;
    try {
      pkgId = new ObjectId(packageId);
    } catch {
      return res.status(400).json({ success: false, error: "Invalid package ID" });
    }

    const pack = await db.collection("ad_packages").findOne({ _id: pkgId });
    if (!pack) return res.status(404).json({ success: false, error: "Package not found" });

    const propId = propertyId ? new ObjectId(propertyId) : undefined;

    // Create transaction in our DB
    const merchantTransactionId = paymentDetails.merchantTransactionId; // we generate on client or server
    const now = new Date();

    const txDoc = {
      userId,
      packageId: pkgId,
      propertyId: propId,
      amount: Number(pack.price || 0),
      currency: "INR",
      paymentMethod: "phonepe",
      paymentDetails: paymentDetails || {},
      merchantTransactionId,        // stable id (ours)
      phonepeTxnId: null as null | string, // PhonePe's txn id after success
      status: "pending",
      packageName: pack.name,
      packageDuration: pack.duration,
      createdAt: now,
      updatedAt: now,
    };

    const insertRes = await db.collection("transactions").insertOne(txDoc);

    // Build PhonePe Pay Page request
    const baseUrl = getBaseUrl(req);
    const payEndpoint = "/pg/v1/pay";

    const payRequest = {
      merchantId: config.merchantId,
      merchantTransactionId,
      merchantUserId: userId.toString(),
      amount: Number(pack.price) * 100, // paise
      redirectUrl: `${baseUrl}/payment-callback?packageId=${pkgId.toString()}&propertyId=${propId?.toString() || ""}&transactionId=${merchantTransactionId}`,
      redirectMode: "POST",
      callbackUrl: `${baseUrl}/api/payments/phonepe/callback`,
      mobileNumber: (req as any).userPhone || undefined,
      paymentInstrument: { type: "PAY_PAGE" },
    };

    const payload = Buffer.from(JSON.stringify(payRequest)).toString("base64");
    const xVerify = generateChecksum(payload, payEndpoint, config.saltKey, config.saltIndex);
    const apiRoot = config.testMode
      ? "https://api-preprod.phonepe.com/apis/pg-sandbox"
      : "https://api.phonepe.com/apis/hermes";

    const resp = await fetch(`${apiRoot}${payEndpoint}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-VERIFY": xVerify,
        "X-MERCHANT-ID": config.merchantId,
      },
      body: JSON.stringify({ request: payload }),
    });

    let instrumentResponse: any = undefined;
    const respJson = await resp.json().catch(() => null);

    if (resp.ok && respJson?.data) {
      instrumentResponse = respJson.data;
    } else {
      console.error("PhonePe init failed:", resp.status, respJson);
    }

    const out: ApiResponse<{ transactionId: string; status: string; instrumentResponse?: any }> = {
      success: true,
      data: {
        transactionId: insertRes.insertedId.toString(),
        status: "pending",
        instrumentResponse,
      },
    };
    return res.json(out);
  } catch (err) {
    console.error("Error creating PhonePe transaction:", err);
    return res.status(500).json({ success: false, error: "Failed to create transaction" });
  }
};

/**
 * POST /api/payments/phonepe/callback
 * PhonePe server will POST here. We verify checksum, decode payload and mark transaction.
 */
export const phonePeCallback: RequestHandler = async (req, res) => {
  try {
    const config = await getPhonePeConfig();
    if (!config) return res.status(400).json({ success: false, error: "PhonePe not configured" });

    const { response } = req.body as { response?: string };
    const xVerify = (req.headers["x-verify"] as string) || (req.headers["x-VERIFY"] as string);

    if (!response || !xVerify) {
      return res.status(400).json({ success: false, error: "Invalid callback data" });
    }

    if (!verifyChecksum(response, xVerify, config.saltKey)) {
      return res.status(400).json({ success: false, error: "Invalid checksum" });
    }

    // Decode base64 response
    const decoded = JSON.parse(Buffer.from(response, "base64").toString("utf-8"));

    // Expected structure: { success, code, message, data: { merchantId, merchantTransactionId, transactionId, amount, state, ... } }
    const data = decoded?.data || {};
    const merchantTransactionId: string = data.merchantTransactionId;
    const phonepeTxnId: string = data.transactionId;
    const state: string = data.state; // COMPLETED / PENDING / FAILED

    const db = getDatabase();

    // Update our transaction by merchantTransactionId
    const tx = await db.collection("transactions").findOne({ merchantTransactionId });
    if (!tx) {
      console.error("Transaction not found for merchantTransactionId:", merchantTransactionId);
      return res.status(200).json({ success: true }); // acknowledge anyway
    }

    const newStatus = state === "COMPLETED" ? "paid" : state === "FAILED" ? "failed" : "processing";

    await db.collection("transactions").updateOne(
      { _id: tx._id },
      {
        $set: {
          status: newStatus,
          phonepeTxnId,
          phonepeResponse: decoded,
          updatedAt: new Date(),
          ...(newStatus === "paid" ? { paidAt: new Date() } : {}),
        },
      }
    );

    // If paid and property exists → activate package on property (same logic as payments.ts)
    if (newStatus === "paid" && tx.propertyId && tx.packageId) {
      const package_ = await db.collection("ad_packages").findOne({ _id: new ObjectId(String(tx.packageId)) });
      if (package_) {
        const packageExpiry = new Date();
        packageExpiry.setDate(packageExpiry.getDate() + Number(package_.duration || 0));

        await db.collection("properties").updateOne(
          { _id: new ObjectId(String(tx.propertyId)) },
          {
            $set: {
              packageId: new ObjectId(String(tx.packageId)),
              packageExpiry,
              featured: package_.type === "featured" || package_.type === "premium",
              updatedAt: new Date(),
            },
          }
        );
      }
    }

    return res.json({ success: true, message: "Callback processed" });
  } catch (err) {
    console.error("PhonePe callback error:", err);
    return res.status(500).json({ success: false, error: "Failed to process callback" });
  }
};

/**
 * GET /api/payments/phonepe/status/:merchantTransactionId
 * Poll PhonePe for status (uses merchantTransactionId).
 */
export const getPhonePePaymentStatus: RequestHandler = async (req, res) => {
  try {
    const config = await getPhonePeConfig();
    if (!config) return res.status(400).json({ success: false, error: "PhonePe not configured" });

    const merchantTransactionId = req.params.merchantTransactionId;
    if (!merchantTransactionId) {
      return res.status(400).json({ success: false, error: "Missing merchantTransactionId" });
    }

    const endpoint = `/pg/v1/status/${config.merchantId}/${merchantTransactionId}`;
    const xVerify = generateChecksum("", endpoint, config.saltKey, config.saltIndex);

    const apiRoot = config.testMode
      ? "https://api-preprod.phonepe.com/apis/pg-sandbox"
      : "https://api.phonepe.com/apis/hermes";

    const r = await fetch(`${apiRoot}${endpoint}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "X-VERIFY": xVerify,
        "X-MERCHANT-ID": config.merchantId,
      },
    });

    const j = await r.json().catch(() => null);

    // Update local transaction if found
    if (j?.success) {
      const db = getDatabase();
      const state = j.data?.state;
      const newStatus = state === "COMPLETED" ? "paid" : state === "FAILED" ? "failed" : "processing";

      await db.collection("transactions").updateOne(
        { merchantTransactionId },
        {
          $set: {
            status: newStatus,
            phonepeResponse: j.data,
            updatedAt: new Date(),
            ...(newStatus === "paid" ? { paidAt: new Date() } : {}),
          },
        }
      );
    }

    const out: ApiResponse<any> = { success: !!j?.success, data: j?.data || j };
    return res.json(out);
  } catch (err) {
    console.error("Error checking PhonePe payment status:", err);
    return res.status(500).json({ success: false, error: "Failed to check payment status" });
  }
};

/**
 * (Optional) GET /api/payments/methods — if you want this controller to serve it.
 * Otherwise use payments.ts version; both return a `phonepe` block.
 */
export const getPaymentMethodsWithPhonePe: RequestHandler = async (_req, res) => {
  try {
    const cfg = await getPhonePeConfig();

    const paymentMethods = {
      upi: {
        enabled: true,
        upiId: "aashishproperty@paytm",
        qrCode: "/api/payments/upi-qr",
      },
      bankTransfer: {
        enabled: true,
        bankName: "State Bank of India",
        accountNumber: "1234567890",
        ifscCode: "SBIN0001234",
        accountHolder: "Aashish Property",
      },
      online: {
        enabled: true,
        gateways: ["razorpay", "paytm"],
      },
      phonepe: {
        enabled: !!cfg,
        merchantId: cfg?.merchantId || "",
        testMode: cfg ? cfg.testMode : true,
      },
    };

    const out: ApiResponse<any> = { success: true, data: paymentMethods };
    return res.json(out);
  } catch (err) {
    console.error("Error fetching payment methods:", err);
    return res.status(500).json({ success: false, error: "Failed to fetch payment methods" });
  }
};
