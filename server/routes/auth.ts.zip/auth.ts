// server/routes/auth.ts
import type { RequestHandler } from "express";
import { getDatabase, connectToDatabase } from "../db/mongodb";
import { User, ApiResponse } from "@shared/types";
import { ObjectId } from "mongodb";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import { sendWelcomeNotification } from "./notifications";
import { getAdmin } from "../firebaseAdmin";

/* ------------------------------- Config ---------------------------------- */
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const SALT_ROUNDS = 10;
const CORS_ALLOW = (process.env.CORS_ALLOW_ORIGINS || "")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);

/* ------------------------------ Small utils ------------------------------ */

function nowIso() { return new Date().toISOString(); }

function toE164(phone: string) {
  const digits = String(phone || "").replace(/\D/g, "");
  if (!digits) return phone;
  if (digits.length === 10) return `+91${digits}`;
  if (digits.startsWith("91") && digits.length === 12) return `+${digits}`;
  return phone.startsWith("+") ? phone : `+${digits}`;
}

function pickIdTokenFromReq(req: any): { idToken?: string; userType?: string; where: string } {
  const bodyToken: string | undefined = req.body?.idToken;
  const authHeader: string = req.headers?.authorization || req.headers?.Authorization || "";
  const bearer = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (bodyToken) return { idToken: bodyToken, userType: req.body?.userType, where: "body.idToken" };
  if (bearer) return { idToken: bearer, userType: req.body?.userType, where: "Authorization:Bearer" };
  return { userType: req.body?.userType, where: "none" };
}

function signAppJwt(payload: Record<string, any>) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d" });
}

/* -------------------------- Firebase verification ------------------------ */
/**
 * Verify Firebase ID token and ensure same project.
 * Returns decoded + hydrated {email,name,phone} from Admin if missing.
 */
async function verifyFirebaseIdTokenStrict(idToken: string) {
  const admin = getAdmin();
  const t0 = Date.now();
  const decoded = await admin.auth().verifyIdToken(idToken);
  console.log("[AUTH] verifyIdToken OK", {
    at: nowIso(),
    ms: Date.now() - t0,
    uid: decoded.uid,
    email: decoded.email,
    aud: decoded.aud,
    iss: decoded.iss,
  });

  const expectedProject =
    process.env.FIREBASE_PROJECT_ID ||
    process.env.VITE_FIREBASE_PROJECT_ID ||
    (admin.app?.options?.projectId as string | undefined);

  if (expectedProject && decoded.aud && decoded.aud !== expectedProject) {
    console.warn("[AUTH] Token audience mismatch", {
      token_aud: decoded.aud,
      expectedProject,
    });
  }

  let email = decoded.email || "";
  let name = (decoded as any).name || "";
  let phone = decoded.phone_number ? toE164(decoded.phone_number) : "";

  if (!email || !name) {
    try {
      const rec = await admin.auth().getUser(decoded.uid);
      email = email || rec.email || "";
      name = name || rec.displayName || "";
      console.log("[AUTH] Hydrated profile from Admin", { email, name });
    } catch (e: any) {
      console.warn("[AUTH] getUser hydrate failed", e?.message || e);
    }
  }

  return { decoded, email, name, phone };
}

/* ----------------------------- DB helpers -------------------------------- */

async function ensureDbReady() {
  try {
    getDatabase(); // if initialized, this won't throw
  } catch {
    console.log("[DB] not initialized → connecting…");
    await connectToDatabase();
    console.log("[DB] connected");
  }
}

/**
 * Upsert user by phone (pref) or email; returns { user, isNew }
 */
async function upsertUserFromFirebaseIdentity(
  email: string,
  phone: string,
  name: string,
  uid: string,
  rawUserType?: string,
) {
  await ensureDbReady();
  const db = getDatabase();

  console.log("[DB] upsert user identity", { email, phone, name, uid, rawUserType });

  let user =
    (phone && (await db.collection("users").findOne({ phone }))) ||
    (email && (await db.collection("users").findOne({ email })));

  const resolvedType = ((): string => {
    const t = (rawUserType || "").toLowerCase();
    if (["seller", "buyer", "agent", "admin", "staff"].includes(t)) return t;
    return "seller"; // default for your app
  })();

  const now = new Date();

  if (!user) {
    const newUser: any = {
      name: name || (phone ? `User ${phone.slice(-4)}` : email?.split("@")[0] || "User"),
      email,
      phone,
      userType: resolvedType,
      firebaseUid: uid,
      createdAt: now,
      updatedAt: now,
    };
    const ins = await db.collection("users").insertOne(newUser);
    user = { _id: ins.insertedId, ...newUser };
    console.log("[DB] user created", { _id: String(ins.insertedId), email, phone, userType: resolvedType });
    return { user, isNew: true };
  } else {
    await db.collection("users").updateOne(
      { _id: user._id },
      { $set: { firebaseUid: uid, lastLogin: now, updatedAt: now } },
    );
    console.log("[DB] user updated lastLogin", { _id: String(user._id) });
    return { user, isNew: false };
  }
}

function makeAuthResponse(user: any) {
  const token = signAppJwt({
    userId: String(user._id),
    userType: user.userType,
    email: user.email,
    phone: user.phone,
  });

  const api: ApiResponse<{ token: string; user: any }> = {
    success: true,
    data: {
      token,
      user: {
        id: String(user._id),
        name: user.name,
        email: user.email,
        phone: user.phone,
        userType: user.userType,
      },
    },
    message: "Authentication successful",
  };

  // backward-compat (flat fields)
  return { ...api, token, user: api.data.user };
}

/* ----------------------------- Register new user --------------------------- */
export const registerUser: RequestHandler = async (req, res) => {
  const t0 = Date.now();
  try {
    await ensureDbReady();
    const db = getDatabase();
    const {
      name,
      email,
      phone,
      password,
      userType,
      experience,
      specializations,
      serviceAreas,
    } = req.body;

    console.log("[AUTH] register", { name, email, phone, userType });

    if (!name || !email || !phone || !password || !userType) {
      return res.status(400).json({
        success: false,
        error:
          "Missing required fields: name, email, phone, password, and userType are required",
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ success: false, error: "Invalid email format" });
    }
    if (String(phone).replace(/\D/g, "").length < 10) {
      return res
        .status(400)
        .json({ success: false, error: "Phone number must be at least 10 digits" });
    }
    if (!["seller", "buyer", "agent"].includes(userType)) {
      return res
        .status(400)
        .json({ success: false, error: "Invalid user type. Must be seller, buyer, or agent" });
    }

    const existingUser = await db
      .collection("users")
      .findOne({ $or: [{ email }, { phone }] });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: "User with this email or phone already exists",
      });
    }

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    const emailVerificationToken = crypto.randomBytes(32).toString("hex");
    const emailVerificationExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const newUser: Omit<User, "_id"> = {
      name,
      email,
      phone,
      password: hashedPassword,
      userType,
      emailVerified: false,
      emailVerificationToken,
      emailVerificationExpiry,
      preferences: {
        propertyTypes: [],
        priceRange: { min: 0, max: 10000000 },
        locations: [],
      },
      favorites: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    if (userType === "agent") {
      (newUser as any).agentProfile = {
        experience: parseInt(experience) || 0,
        specializations: specializations || [],
        rating: 0,
        reviewCount: 0,
        aboutMe: "",
        serviceAreas: serviceAreas || [],
      };
      (newUser as any).properties = [];
    }

    const result = await db.collection("users").insertOne(newUser);

    try {
      await sendWelcomeNotification(result.insertedId.toString(), name, userType);
    } catch (e) {
      console.warn("[AUTH] welcome notification failed", (e as any)?.message || e);
    }

    const token = signAppJwt({
      userId: result.insertedId.toString(),
      userType,
      email,
    });

    const verificationLink = `${
      process.env.BASE_URL || "http://localhost:8080"
    }/api/auth/verify-email?token=${emailVerificationToken}`;

    const response: ApiResponse<{
      token: string;
      user: any;
      verificationLink?: string;
    }> = {
      success: true,
      data: {
        token,
        user: {
          id: result.insertedId.toString(),
          name,
          email,
          phone,
          userType,
          emailVerified: false,
        },
        verificationLink,
      },
      message:
        "User registered successfully. Please check your email to verify your account.",
    };

    console.log("[AUTH] register OK", { id: String(result.insertedId), ms: Date.now() - t0 });
    res.status(201).json(response);
  } catch (error: any) {
    console.error("[AUTH] register error:", error);
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        error: "User with this email or phone already exists",
      });
    }
    res.status(500).json({
      success: false,
      error: `Failed to register user: ${error.message}`,
    });
  }
};

/* ------------------------------- Password login --------------------------- */
export const loginUser: RequestHandler = async (req, res) => {
  const t0 = Date.now();
  try {
    await ensureDbReady();
    const db = getDatabase();
    const { email, phone, password, username } = req.body;

    console.log("[AUTH] login attempt", { email, phone, username });

    let query: any = {};
    if (username) {
      query = { username };
    } else if (email && phone) {
      const digits = String(phone || "").replace(/\D/g, "");
      const e164 = toE164(String(phone || ""));
      const spaced = digits.length >= 10 ? `+91 ${digits.slice(-10)}` : undefined;
      const plain = digits.length >= 10 ? `+91${digits.slice(-10)}` : undefined;
      query = {
        $or: [
          { email },
          ...(spaced ? [{ phone: spaced }] : []),
          ...(plain ? [{ phone: plain }] : []),
          { phone },
          { phone: e164 },
        ],
      };
    } else if (email) {
      query = { email };
    } else if (phone) {
      const digits = String(phone || "").replace(/\D/g, "");
      const e164 = toE164(String(phone || ""));
      const spaced = digits.length >= 10 ? `+91 ${digits.slice(-10)}` : undefined;
      const plain = digits.length >= 10 ? `+91${digits.slice(-10)}` : undefined;
      query = {
        $or: [
          ...(spaced ? [{ phone: spaced }] : []),
          ...(plain ? [{ phone: plain }] : []),
          { phone },
          { phone: e164 },
        ],
      };
    } else {
      return res.status(400).json({
        success: false,
        error: "Email, phone number, or username is required",
      });
    }

    const user = await db.collection("users").findOne(query);
    if (!user) {
      console.warn("[AUTH] login invalid (user not found)", { query });
      return res.status(401).json({ success: false, error: "Invalid credentials" });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      console.warn("[AUTH] login invalid (bad password)", { id: String(user._id) });
      return res.status(401).json({ success: false, error: "Invalid credentials" });
    }

    await db.collection("users").updateOne(
      { _id: user._id },
      {
        $set: { lastLogin: new Date(), updatedAt: new Date() },
        $unset: user.isFirstLogin ? { isFirstLogin: 1 } : {},
      }
    );

    const token = signAppJwt({
      userId: user._id.toString(),
      userType: user.userType,
      email: user.email,
      role: user.role || user.userType,
    });

    const userResponse: any = {
      id: user._id.toString(),
      name: user.name,
      email: user.email,
      phone: user.phone,
      userType: user.userType,
    };

    if (user.userType === "staff" || user.role) {
      userResponse.role = user.role;
      userResponse.permissions = user.permissions || [];
      userResponse.isFirstLogin = user.isFirstLogin || false;
      userResponse.username = user.username;

      const roleInfo = {
        super_admin: { displayName: "Super Admin", color: "purple" },
        content_manager: { displayName: "Content Manager", color: "blue" },
        sales_manager: { displayName: "Sales Manager", color: "green" },
        support_executive: { displayName: "Support Executive", color: "orange" },
        admin: { displayName: "Admin", color: "gray" },
      } as Record<string, any>;

      userResponse.roleInfo = roleInfo[user.role] || {
        displayName: user.role,
        color: "gray",
      };
    }

    const response: ApiResponse<{ token: string; user: any }> = {
      success: true,
      data: { token, user: userResponse },
      message: user.isFirstLogin
        ? "First login successful - please change your password"
        : "Login successful",
    };

    console.log("[AUTH] login OK", { id: String(user._id), ms: Date.now() - t0 });
    res.json(response);
  } catch (error) {
    console.error("[AUTH] login error:", error);
    res.status(500).json({ success: false, error: "Failed to login" });
  }
};

/* ---------------------- Deprecated demo OTP endpoints --------------------- */
export const sendOTP: RequestHandler = async (_req, res) => {
  return res.status(410).json({
    success: false,
    error:
      "Deprecated. Use Firebase phone auth on client and POST /api/auth/firebase-login with idToken.",
  });
};

export const verifyOTP: RequestHandler = async (_req, res) => {
  return res.status(410).json({
    success: false,
    error:
      "Deprecated. Use Firebase phone auth on client and POST /api/auth/firebase-login with idToken.",
  });
};

/* ---------- Firebase Phone/Google token → our session (unified) ----------- */
export const firebaseLogin: RequestHandler = async (req, res) => {
  const t0 = Date.now();
  try {
    const origin = req.headers.origin as string | undefined;
    console.log("[AUTH] /firebase-login hit", {
      at: nowIso(),
      origin,
      allow: CORS_ALLOW,
      hasBody: !!req.body,
      authHeader: !!req.headers?.authorization,
    });

    const picked = pickIdTokenFromReq(req);
    const tokenToUse = picked.idToken;
    const userType = picked.userType;

    console.log("[AUTH] token source", {
      where: picked.where,
      tokenLen: tokenToUse ? tokenToUse.length : 0,
      userType,
    });

    if (!tokenToUse) {
      return res.status(400).json({ success: false, error: "idToken required" });
    }

    let decoded, email, name, phone;
    try {
      ({ decoded, email, name, phone } = await verifyFirebaseIdTokenStrict(tokenToUse));
    } catch (e: any) {
      console.error("[AUTH] verifyIdToken failed", {
        message: e?.message,
        code: e?.code,
        info: e?.errorInfo,
      });
      const msg =
        e?.code === "auth/argument-error"
          ? "Token audience mismatch / wrong Firebase project"
          : e?.message || "Invalid token";
      return res.status(401).json({ success: false, error: msg });
    }

    if (!email && !phone) {
      return res
        .status(400)
        .json({ success: false, error: "Token has no email/phone" });
    }

    const { user, isNew } = await upsertUserFromFirebaseIdentity(
      email,
      phone,
      name,
      decoded.uid,
      userType,
    );

    const response = makeAuthResponse(user);
    console.log("[AUTH] /firebase-login OK", {
      uid: decoded.uid,
      email,
      userId: response.user.id,
      isNew,
      ms: Date.now() - t0,
    });
    return res.json(response);
  } catch (err: any) {
    console.error("[AUTH] /firebase-login error:", err?.message || err);
    return res.status(401).json({ success: false, error: "Invalid token" });
  }
};

/* ----------------------------- Google authentication ---------------------- */
/**
 * Keep /google endpoint for backward compatibility.
 * Internally do exactly what firebaseLogin does so the behaviour is identical.
 */
export const googleAuth: RequestHandler = async (req, res) => {
  const t0 = Date.now();
  try {
    const origin = req.headers.origin as string | undefined;
    console.log("[AUTH] /auth/google hit", {
      at: nowIso(),
      origin,
      allow: CORS_ALLOW,
      hasBody: !!req.body,
      authHeader: !!req.headers?.authorization,
    });

    const picked = pickIdTokenFromReq(req);
    const idToken = picked.idToken;
    const userType = picked.userType;

    console.log("[AUTH] /auth/google token source", {
      where: picked.where,
      tokenLen: idToken ? idToken.length : 0,
      userType,
    });

    if (!idToken) {
      return res.status(400).json({ success: false, error: "Missing idToken" });
    }

    let decoded, email, name, phone;
    try {
      ({ decoded, email, name, phone } = await verifyFirebaseIdTokenStrict(idToken));
    } catch (e: any) {
      console.error("[AUTH] /auth/google verify failed", {
        message: e?.message,
        code: e?.code,
        info: e?.errorInfo,
      });
      const msg =
        e?.code === "auth/argument-error"
          ? "Token audience mismatch / wrong Firebase project"
          : e?.message || "Invalid Google user data";
      return res.status(401).json({ success: false, error: msg });
    }

    if (!email) {
      return res
        .status(401)
        .json({ success: false, error: "Email not present in Google token" });
    }

    const { user, isNew } = await upsertUserFromFirebaseIdentity(
      email,
      phone,
      name,
      decoded.uid,
      userType,
    );

    const response = makeAuthResponse(user);
    console.log("[AUTH] /auth/google OK", {
      uid: decoded.uid,
      email,
      userId: response.user.id,
      isNew,
      ms: Date.now() - t0,
    });
    return res.json(response);
  } catch (err: any) {
    console.error("[AUTH] /auth/google error:", err?.message || err);
    return res
      .status(401)
      .json({ success: false, error: "Invalid Google user data" });
  }
};

/* ------------------------------ Profile APIs ------------------------------ */
export const getUserProfile: RequestHandler = async (req, res) => {
  try {
    await ensureDbReady();
    const db = getDatabase();
    const userId = (req as any).userId;
    console.log("[AUTH] getUserProfile", { userId });
    const user = await db.collection("users").findOne({ _id: new ObjectId(userId) });
    if (!user) return res.status(404).json({ success: false, error: "User not found" });

    const { password, ...userWithoutPassword } = user;
    const response: ApiResponse<any> = { success: true, data: userWithoutPassword };
    res.json(response);
  } catch (error) {
    console.error("[AUTH] getUserProfile error:", error);
    res.status(500).json({ success: false, error: "Failed to fetch user profile" });
  }
};

export const updateUserProfile: RequestHandler = async (req, res) => {
  try {
    await ensureDbReady();
    const db = getDatabase();
    const userId = (req as any).userId;
    const updateData = { ...req.body };

    delete (updateData as any).password;
    delete (updateData as any)._id;

    console.log("[AUTH] updateUserProfile", { userId, keys: Object.keys(updateData) });

    const result = await db.collection("users").updateOne(
      { _id: new ObjectId(userId) },
      { $set: { ...updateData, updatedAt: new Date() } }
    );

    if (result.matchedCount === 0) {
      return res.status(404).json({ success: false, error: "User not found" });
    }

    const response: ApiResponse<{ message: string }> = {
      success: true,
      data: { message: "Profile updated successfully" },
    };
    res.json(response);
  } catch (error) {
    console.error("[AUTH] updateUserProfile error:", error);
    res.status(500).json({ success: false, error: "Failed to update profile" });
  }
};
