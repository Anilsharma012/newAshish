// server/middleware/auth.ts
import { Request, RequestHandler } from "express";
import jwt from "jsonwebtoken";
import { adminAuth } from "../firebaseAdmin"; // <= path sahi hai: middleware/.. -> firebaseAdmin.ts

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const SESSION_COOKIE_NAME = "__session"; // agar server session cookie use karte ho

export interface AuthenticatedRequest extends Request {
  userId?: string;
  userType?: string;
  email?: string;
  role?: string;
  authSource?: "firebase" | "jwt";
}

function extractToken(req: Request): { token?: string; source: string } {
  const h = req.headers.authorization;
  if (h && h.startsWith("Bearer ")) return { token: h.slice(7).trim(), source: "header" };

  // optional: cookie fallback (cookie-parser enabled hona chahiye)
  // @ts-ignore
  if (req.cookies?.[SESSION_COOKIE_NAME]) return { token: req.cookies[SESSION_COOKIE_NAME], source: "cookie" };

  // optional: body/query me idToken
  const bodyToken = (req as any).body?.idToken;
  if (typeof bodyToken === "string") return { token: bodyToken, source: "body.idToken" };

  const queryToken = (req as any).query?.idToken;
  if (typeof queryToken === "string") return { token: String(queryToken), source: "query.idToken" };

  return { token: undefined, source: "none" };
}

export const authenticateToken: RequestHandler = async (req: AuthenticatedRequest, res, next) => {
  const { token, source } = extractToken(req);

  if (!token) {
    return res.status(401).json({ success: false, error: "Access token required" });
  }

  // 1) Try Firebase ID token (Google sign-in ke baad jo milta hai)
  try {
    const decoded = await adminAuth().verifyIdToken(token, true);
    req.userId = decoded.uid;
    req.email = decoded.email || "";
    const claims: any = decoded; // custom claims agar set kiye ho to yahan milenge
    req.userType = claims.userType || claims.role || "user";
    req.role = claims.role || claims.userType || "user";
    req.authSource = "firebase";
    return next();
  } catch (e) {
    // 2) Fallback: tumhari apni JWT (JWT_SECRET se sign ki hui)
    try {
      const decoded: any = jwt.verify(token, JWT_SECRET);
      req.userId = decoded.userId;
      req.email = decoded.email || "";
      req.userType = decoded.userType || decoded.role || "user";
      req.role = decoded.role || decoded.userType || "user";
      req.authSource = "jwt";
      return next();
    } catch (err: any) {
      console.error("🔐 auth verify failed", { source, err: err?.message });
      return res.status(401).json({ success: false, error: "Invalid or expired token" });
    }
  }
};

export const requireAdmin: RequestHandler = (req: AuthenticatedRequest, res, next) => {
  const { userType, role, userId } = req;
  console.log("🔐 Admin middleware check:", { userType, role, userId });

  if (userType !== "admin" && userType !== "staff") {
    console.log("❌ Access denied - not admin or staff");
    return res.status(403).json({ success: false, error: "Admin access required" });
  }

  console.log("✅ Admin access granted");
  next();
};

export const requireSellerOrAgent: RequestHandler = (req: AuthenticatedRequest, res, next) => {
  const userType = req.userType || "user";
  if (!["seller", "agent", "admin"].includes(userType)) {
    return res.status(403).json({ success: false, error: "Seller or agent access required" });
  }
  next();
};

export const requirePermission = (permission: string): RequestHandler => {
  return (req: AuthenticatedRequest, res, next) => {
    const userType = req.userType || "user";
    const role = req.role || "user";

    if (userType === "admin") return next();

    if (userType === "staff") {
      const rolePermissions: Record<string, string[]> = {
        super_admin: ["*"],
        content_manager: ["content.view", "content.create", "content.manage", "blog.manage", "blog.view"],
        sales_manager: ["users.view", "sellers.manage", "sellers.verify", "sellers.view", "payments.view", "packages.manage", "ads.view", "analytics.view"],
        support_executive: ["users.view", "support.view", "reports.view", "content.view"],
        admin: ["content.view", "users.view", "ads.view", "analytics.view"],
      };
      const userPermissions = rolePermissions[role] || [];
      if (userPermissions.includes("*") || userPermissions.includes(permission)) return next();
    }

    return res.status(403).json({ success: false, error: `Permission required: ${permission}` });
  };
};
